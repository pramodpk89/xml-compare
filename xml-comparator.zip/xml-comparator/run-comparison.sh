#!/bin/bash
# XML Comparison Tool Launcher
# Run this script to compare XML files

echo "XML Comparator Tool"
echo "=================="

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "ERROR: Java is not installed or not in your PATH"
    echo "Please install Java 11 or higher and try again"
    exit 1
fi

# Create directories if they don't exist
if [ ! -d "source" ]; then
    echo "Creating source directory..."
    mkdir source
    echo
    echo "Please put your original XML files in the 'source' folder"
    echo
fi

if [ ! -d "compare-with" ]; then
    echo "Creating compare-with directory..."
    mkdir compare-with
    echo
    echo "Please put your modified XML files in the 'compare-with' folder"
    echo
fi

# Check if source directory has XML files
if [ ! "$(ls -A source/*.xml 2>/dev/null)" ]; then
    echo "WARNING: No XML files found in source directory"
    echo "Please add XML files to the source directory"
    exit 1
fi

echo "Running comparison..."
echo

# Run the comparison
java -jar xml-comparator.jar --source ./source

if [ $? -eq 0 ]; then
    echo
    echo "Comparison completed successfully!"
    echo "Results saved to comparison-report.xlsx"
else
    echo
    echo "Error during comparison. Please check the logs."
fi

# Make script executable
chmod +x run-comparison.sh