# XML Comparator Tool

A simple Java tool that compares XML files and generates Excel reports showing all differences. Perfect for verifying changes during XML data migrations.

## How to Use (Quick Start)

1. Download the `xml-comparator.jar` file
2. Create two folders: `source` and `compare-with`
3. Place your original XML files in the `source` folder
4. Place your modified XML files in the `compare-with` folder
5. Run the tool:

```bash
java -jar xml-comparator.jar --source ./source
```

## Directory Setup

Set up your directories like this:

```
project-folder/
├── source/                # Original XML files
│   ├── file1.xml
│   └── file2.xml
├── compare-with/          # Modified XML files (same names as source)
│   ├── file1.xml
│   └── file2.xml
└── xml-comparator.jar
```

## Running the Tool

### Basic Command (Recommended)

```bash
java -jar xml-comparator.jar --source ./source
```

This will:
- Compare XML files in `./source` with matching files in `./compare-with`
- Create `comparison-report.xlsx` in the current directory

### Specifying All Options

```bash
java -jar xml-comparator.jar --source /path/to/source --target /path/to/target --output /path/to/report.xlsx
```

### Large XML Files

For files over 100MB, increase memory:

```bash
java -Xmx4g -jar xml-comparator.jar --source ./source
```

## Understanding the Report

The Excel report shows:

- **Summary Tab**: Overview of all differences found
- **File Tabs**: One tab per XML file with detailed differences:
  - Green rows = Additions in target XML
  - Red rows = Removals from source XML
  - Yellow rows = Modified values
  - XPath shows exact location of each difference
  - Side-by-side comparison of values

## Example Scenarios

### Simple Value Changes

If you changed the value of an attribute:

```xml
<!-- source/data.xml -->
<library name="Central Library">
```

```xml
<!-- compare-with/data.xml -->
<library name="Main Library">
```

Report will show:
- Library name changed from "Central Library" to "Main Library"

### Added Elements

If you added new elements in the target:

```xml
<!-- source/data.xml -->
<books>
  <book id="B001" title="The Great Gatsby" />
</books>
```

```xml
<!-- compare-with/data.xml -->
<books>
  <book id="B001" title="The Great Gatsby" />
  <book id="B002" title="New Book" />
</books>
```

Report will show:
- New book element with ID "B002" was added

## Tips for Success

1. Always use matching filenames in both folders
2. Use well-formed XML files (validate before comparing)
3. For complex projects, organize files in matching subdirectories
4. Review the summary tab first to see the most changed files

## Requirements

- Java 11 or higher
- 2GB RAM minimum (4GB recommended for large files)

## Support

If you encounter issues:
1. Check that your XML files are well-formed
2. Verify that filenames match exactly in both directories
3. Try using absolute paths if relative paths aren't working

Report bugs with:
- The exact command you ran
- Example XML files showing the issue
- The error message you received